package com.test.controller;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class ReservationForm {
    private String userId;
    private String sCode;
}
