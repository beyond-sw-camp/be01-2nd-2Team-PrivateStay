package com.test.entity;

public enum ReservationStatus {
    ON_HOLD, RESERVED, CANCELED
}
