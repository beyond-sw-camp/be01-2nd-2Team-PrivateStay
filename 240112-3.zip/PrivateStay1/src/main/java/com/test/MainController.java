package com.test;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class MainController {
 
    @GetMapping("/calender")
    public String main(){
        return "response/static/calender";
    }
    @GetMapping("/sample")
    public String sample(){
        return "sample";
    }
    

}